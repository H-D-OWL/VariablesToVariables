// Copyright H.D OWL. All rights reserved.

#include "Variables_to_variablesBPLibrary.h"
#include "Variables_to_variables.h"
#include "limits.h"

#define LOCTEXT_NAMESPACE "Kismet"

// Varriable To Varriable

// Bool

void UBVar_to_varBPLibrary::BoolToInt64(bool Bool, int64 &Int64)
{
    Int64 = Bool;
}

void UBVar_to_varBPLibrary::BoolToName(bool Bool, FName &Name)
{
    Name = Bool ? TEXT("true") : TEXT("false");
}

void UBVar_to_varBPLibrary::BoolToVector(bool Bool, FVector &Vector)
{
    Vector = FVector(Bool);
}

void UBVar_to_varBPLibrary::BoolToRotator(bool Bool, FRotator &Rotator)
{
    Rotator = FRotator(Bool);
}

// Uint8 (Byte)

void UBVar_to_varBPLibrary::Uint8ToBool(uint8 Byte, bool &Bool)
{
    Bool = Byte ? 1 : 0;
}

void UBVar_to_varBPLibrary::Uint8ToName(uint8 Byte, FName &Name)
{
    Name = (FName(*FString::Printf(TEXT("%d"), Byte)));
}

void UBVar_to_varBPLibrary::Uint8ToVector(uint8 Byte, FVector &Vector)
{
    Vector = FVector(Byte);
}

void UBVar_to_varBPLibrary::Uint8ToRotator(uint8 Byte, FRotator &Rotator)
{
    Rotator = FRotator(Byte);
}

// Int32

void UBVar_to_varBPLibrary::Int32ToName(int32 Int32, FName &Name)
{
    Name = (FName(*FString::Printf(TEXT("%d"), Int32)));
}

void UBVar_to_varBPLibrary::Int32ToRotator(int32 Int32, FRotator &Rotator)
{
    Rotator = FRotator(Int32);
}

// Int64

void UBVar_to_varBPLibrary::Int64ToBool(int64 Int64, bool &Bool)
{
    Bool = Int64 ? 1 : 0;
}

void UBVar_to_varBPLibrary::Int64ToName(int64 Int64, FName &Name)
{
    Name = (FName(*FString::Printf(TEXT("%lld"), Int64)));
}

void UBVar_to_varBPLibrary::Int64ToVector(int64 Int64, FVector &Vector)
{
    Vector = FVector(Int64);
}

void UBVar_to_varBPLibrary::Int64ToRotator(int64 Int64, FRotator &Rotator)
{
    Rotator = FRotator(Int64);
}

// Float

void UBVar_to_varBPLibrary::FloatToBool(float Float, bool &Bool)
{
    Bool = Float ? 1 : 0;
}

void UBVar_to_varBPLibrary::FloatToUint8(float Float, uint8 &Byte)
{
    Byte = Float;
}

void UBVar_to_varBPLibrary::FloatToName(float Float, FName &Name)
{
    Name = (FName(*FString::SanitizeFloat(Float)));
}

void UBVar_to_varBPLibrary::FloatToRotator(float Float, FRotator &Rotator)
{
    Rotator = FRotator(Float);
}

// Name

void UBVar_to_varBPLibrary::NameToBool(FName Name, bool &Bool)
{
    Bool = (FCString::ToBool(*Name.ToString()));
}

void UBVar_to_varBPLibrary::NameToUint8(FName Name, uint8 &Byte)
{
    Byte = (FCString::Atoi(*Name.ToString()));
}

void UBVar_to_varBPLibrary::NameToInt32(FName Name, int32 &Int32)
{
    Int32 = (FCString::Atoi(*Name.ToString()));
}

void UBVar_to_varBPLibrary::NameToInt64(FName Name, int64 &Int64)
{
    Int64 = (FCString::Atoi64(*Name.ToString()));
}

void UBVar_to_varBPLibrary::NameToFloat(FName Name, float &Float)
{
    Float = (FCString::Atof(*Name.ToString()));
}

void UBVar_to_varBPLibrary::NameToVector(FName Name, FVector &Vector)
{
    Vector.InitFromString((*Name.ToString()));
}

void UBVar_to_varBPLibrary::NameToRotator(FName Name, FRotator &Rotator)
{
    Rotator.InitFromString((*Name.ToString()));
}

// String

void UBVar_to_varBPLibrary::StringToBool(FString String, bool &Bool)
{
    Bool = (FCString::ToBool(*String));
    FTransform Transform;
}

void UBVar_to_varBPLibrary::StringToUint8(FString String, uint8 &Byte)
{
    Byte = (FCString::Atoi(*String));
}

// Text

void UBVar_to_varBPLibrary::TextToBool(const FText &Text, bool &Bool)
{
    Bool = (FCString::ToBool(*Text.ToString()));
}

void UBVar_to_varBPLibrary::TextToUint8(const FText &Text, uint8 &Byte)
{
    Byte = (FCString::Atoi((*Text.ToString())));
}

void UBVar_to_varBPLibrary::TextToInt32(const FText &Text, int32 &Int32)
{
    Int32 = (FCString::Atoi(*Text.ToString()));
}

void UBVar_to_varBPLibrary::TextToInt64(const FText &Text, int64 &Int64)
{
    Int64 = (FCString::Atoi64(*Text.ToString()));
}

void UBVar_to_varBPLibrary::TextToFloat(const FText &Text, float &Float)
{
    Float = (FCString::Atof(*Text.ToString()));
}

void UBVar_to_varBPLibrary::TextToName(const FText &Text, FName &Name)
{
    Name = (FName(*Text.ToString()));
}

void UBVar_to_varBPLibrary::TextToVector(const FText &Text, FVector &Vector)
{
    Vector.InitFromString((*Text.ToString()));
}

void UBVar_to_varBPLibrary::TextToRotator(const FText &Text, FRotator &Rotator)
{
    Rotator.InitFromString((*Text.ToString()));
}

// Vector

void UBVar_to_varBPLibrary::VectorToName(FVector Vector, FName &Name)
{
    Name = FName(Vector.ToString());
}

void UBVar_to_varBPLibrary::VectorToTransformScale(FVector Vector, FTransform &Transform)
{
    FTransform IntermediateTransform{
        FRotator{},     // Rotation
        FVector{},      // Location
        FVector{Vector} // Scale

    };
    Transform = IntermediateTransform;
}

// Rotator

void UBVar_to_varBPLibrary::RotatorToName(FRotator Rotator, FName &Name)
{
    Name = FName(Rotator.ToString());
}

void UBVar_to_varBPLibrary::RotatorToTransform(FRotator Rotator, FTransform &Transform)
{
    Transform = (FTransform(Rotator));
}
// Transform

void UBVar_to_varBPLibrary::TransformToName(FTransform Transform, FName &Name)
{
    Name = FName(Transform.ToString());
}

void UBVar_to_varBPLibrary::TransformToVectorLocation(FTransform Transform, FVector &Vector)
{
    Vector = Transform.GetLocation();
}

void UBVar_to_varBPLibrary::TransformToRotator(FTransform Transform, FRotator &Rotator)
{
    Rotator = FRotator(Transform.GetRotation());
}

void UBVar_to_varBPLibrary::TransformToVectorScale(FTransform Transform, FVector &Vector)
{
    Vector = Transform.GetScale3D();
}

// Array To Array

// Bool

void UBVar_to_varBPLibrary::ArrayBoolToArrayUint8(TArray<bool> ArrayBool, TArray<uint8> &ArrayUint8)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayUint8.Add(ArrayElement ? 1 : 0);
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayInt32(TArray<bool> ArrayBool, TArray<int32> &ArrayInt32)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayInt32.Add(ArrayElement ? 1 : 0);
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayInt64(TArray<bool> ArrayBool, TArray<int64> &ArrayInt64)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayInt64.Add(ArrayElement ? 1 : 0);
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayfloat(TArray<bool> ArrayBool, TArray<float> &ArrayFloat)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayFloat.Add(ArrayElement ? 1.0f : 0.0f);
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayName(TArray<bool> ArrayBool, TArray<FName> &ArrayName)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayName.Add(ArrayElement ? TEXT("true") : TEXT("false"));
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayString(TArray<bool> ArrayBool, TArray<FString> &ArrayString)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayString.Add(ArrayElement ? TEXT("true") : TEXT("false"));
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayText(TArray<bool> ArrayBool, TArray<FText> &ArrayText)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayText.Add(ArrayElement ? LOCTEXT("True", "true") : LOCTEXT("False", "false"));
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayVector(TArray<bool> ArrayBool, TArray<FVector> &ArrayVector)
{
    for (bool ArrayElement : ArrayBool)
    {
        ArrayVector.Add(FVector(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayBoolToArrayRotator(TArray<bool> ArrayBool, TArray<FRotator> &ArrayRotator)
{
    for (uint8 ArrayElement : ArrayBool)
    {
        ArrayRotator.Add(FRotator(ArrayElement));
    }
}

// Uint8 (Byte)

void UBVar_to_varBPLibrary::ArrayUint8ToArrayBool(TArray<uint8> ArrayByte, TArray<bool> &ArrayBool)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayBool.Add(ArrayElement ? 1 : 0);
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayInt32(TArray<uint8> ArrayByte, TArray<int32> &ArrayInt32)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayInt32.Add(ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayInt64(TArray<uint8> ArrayByte, TArray<int64> &ArrayInt64)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayInt64.Add(ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayfloat(TArray<uint8> ArrayByte, TArray<float> &ArrayFloat)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayFloat.Add(ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayName(TArray<uint8> ArrayByte, TArray<FName> &ArrayName)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayName.Add(FName(*FString::Printf(TEXT("%d"), ArrayElement)));
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayString(TArray<uint8> ArrayByte, TArray<FString> &ArrayString)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayString.Add(FString::Printf(TEXT("%d"), ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayText(TArray<uint8> ArrayByte, TArray<FText> &ArrayText)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayText.Add(FText::AsNumber(ArrayElement, &FNumberFormattingOptions::DefaultNoGrouping()));
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayVector(TArray<uint8> ArrayByte, TArray<FVector> &ArrayVector)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayVector.Add(FVector(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayUint8ToArrayRotator(TArray<uint8> ArrayByte,
                                                                 TArray<FRotator> &ArrayRotator)
{
    for (uint8 ArrayElement : ArrayByte)
    {
        ArrayRotator.Add(FRotator(ArrayElement));
    }
}

// Int32

void UBVar_to_varBPLibrary::ArrayInt32ToArrayBool(TArray<int32> ArrayInt32, TArray<bool> &ArrayBool)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayBool.Add(ArrayElement ? 1 : 0);
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayUint8(TArray<int32> ArrayInt32, TArray<uint8> &ArrayByte)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayByte.Add((uint8)ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayInt64(TArray<int32> ArrayInt32, TArray<int64> &ArrayInt64)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayInt64.Add(ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayfloat(TArray<int32> ArrayInt32, TArray<float> &ArrayFloat)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayFloat.Add(ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayName(TArray<int32> ArrayInt32, TArray<FName> &ArrayName)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayName.Add(FName(*FString::Printf(TEXT("%d"), ArrayElement)));
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayString(TArray<int32> ArrayInt32, TArray<FString> &ArrayString)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayString.Add(FString::Printf(TEXT("%d"), ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayText(TArray<int32> ArrayInt32, TArray<FText> &ArrayText)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayText.Add(FText::AsNumber(ArrayElement, &FNumberFormattingOptions::DefaultNoGrouping()));
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayVector(TArray<int32> ArrayInt32, TArray<FVector> &ArrayVector)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayVector.Add(FVector(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayInt32ToArrayRotator(TArray<int32> ArrayInt32, TArray<FRotator> &ArrayRotator)
{
    for (int32 ArrayElement : ArrayInt32)
    {
        ArrayRotator.Add(FRotator(ArrayElement));
    }
}

// Int64

void UBVar_to_varBPLibrary::ArrayInt64ToArrayBool(TArray<int64> ArrayInt64, TArray<bool> &ArrayBool)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayBool.Add(ArrayElement ? 1 : 0);
    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayUint8(TArray<int64> ArrayInt64, TArray<uint8> &ArrayByte)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayByte.Add((uint8)ArrayElement);

    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayInt32(TArray<int64> ArrayInt64, TArray<int32> &ArrayInt32)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayInt32.Add((int32)ArrayElement);

    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayfloat(TArray<int64> ArrayInt64, TArray<float> &ArrayFloat)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayFloat.Add(ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayName(TArray<int64> ArrayInt64, TArray<FName> &ArrayName)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayName.Add(FName(*FString::Printf(TEXT("%lld"), ArrayElement)));
    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayString(TArray<int64> ArrayInt64, TArray<FString> &ArrayString)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayString.Add(FString::Printf(TEXT("%lld"), ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayText(TArray<int64> ArrayInt64, TArray<FText> &ArrayText)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayText.Add(FText::AsNumber(ArrayElement, &FNumberFormattingOptions::DefaultNoGrouping()));
    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayVector(TArray<int64> ArrayInt64, TArray<FVector> &ArrayVector)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayVector.Add(FVector(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayInt64ToArrayRotator(TArray<int64> ArrayInt64, TArray<FRotator> &ArrayRotator)
{
    for (int64 ArrayElement : ArrayInt64)
    {
        ArrayRotator.Add(FRotator(ArrayElement));
    }
}

// Float

void UBVar_to_varBPLibrary::ArrayFloatToArrayBool(TArray<float> ArrayFloat, TArray<bool> &ArrayBool)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayBool.Add(ArrayElement ? 1 : 0);
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayUint8(TArray<float> ArrayFloat, TArray<uint8> &ArrayByte)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayByte.Add((uint8)ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayInt32(TArray<float> ArrayFloat, TArray<int32> &ArrayInt32)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayInt32.Add((int32)ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayInt64(TArray<float> ArrayFloat, TArray<int64> &ArrayInt64)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayInt64.Add((int64)ArrayElement);
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayName(TArray<float> ArrayFloat, TArray<FName> &ArrayName)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayName.Add(FName(*FString::SanitizeFloat(ArrayElement)));
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayString(TArray<float> ArrayFloat, TArray<FString> &ArrayString)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayString.Add(*FString::SanitizeFloat(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayText(TArray<float> ArrayFloat, TArray<FText> &ArrayText)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayText.Add(FText::AsNumber(ArrayElement, &FNumberFormattingOptions::DefaultNoGrouping()));
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayVector(TArray<float> ArrayFloat, TArray<FVector> &ArrayVector)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayVector.Add(FVector(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayFloatToArrayRotator(TArray<float> ArrayFloat, TArray<FRotator> &ArrayRotator)
{
    for (float ArrayElement : ArrayFloat)
    {
        ArrayRotator.Add(FRotator(ArrayElement));
    }
}

// Name

void UBVar_to_varBPLibrary::ArrayNameToArrayBool(TArray<FName> ArrayName, TArray<bool> &ArrayBool)
{
    for (FName ArrayElement : ArrayName)
    {
        ArrayBool.Add(FCString::ToBool(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayUint8(TArray<FName> ArrayName, TArray<uint8> &ArrayByte)
{
    for (FName ArrayElement : ArrayName)
    {
        ArrayByte.Add(FCString::Atoi((*ArrayElement.ToString())));
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayInt32(TArray<FName> ArrayName, TArray<int32> &ArrayInt32)
{
    for (FName ArrayElement : ArrayName)
    {
        ArrayInt32.Add(FCString::Atoi(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayInt64(TArray<FName> ArrayName, TArray<int64> &ArrayInt64)
{
    for (FName ArrayElement : ArrayName)
    {
        ArrayInt64.Add(FCString::Atoi64(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayFloat(TArray<FName> ArrayName, TArray<float> &ArrayFloat)
{
    for (FName ArrayElement : ArrayName)
    {
        ArrayFloat.Add(FCString::Atof(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayName(TArray<FName> ArrayName, TArray<FString> &ArrayString)
{
    for (FName ArrayElement : ArrayName)
    {
        ArrayString.Add(*ArrayElement.ToString());
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayText(TArray<FName> ArrayName, TArray<FText> &ArrayText)
{
    for (FName ArrayElement : ArrayName)
    {
        ArrayText.Add(FText::AsCultureInvariant(ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayVector(TArray<FName> ArrayName, TArray<FVector> &ArrayVector)
{
    FVector OutConvertedVector;
    for (FName ArrayElement : ArrayName)
    {
        OutConvertedVector.InitFromString((*ArrayElement.ToString()));
        ArrayVector.Add(OutConvertedVector);
    }
}

void UBVar_to_varBPLibrary::ArrayNameToArrayRotator(TArray<FName> ArrayName, TArray<FRotator> &ArrayRotator)
{
    FRotator OutConvertedRotator;
    for (FName ArrayElement : ArrayName)
    {
        OutConvertedRotator.InitFromString((*ArrayElement.ToString()));
        ArrayRotator.Add(OutConvertedRotator);
    }
}

// String

void UBVar_to_varBPLibrary::ArrayStringToArrayBool(TArray<FString> ArrayString, TArray<bool> &ArrayBool)
{
    for (FString ArrayElement : ArrayString)
    {
        ArrayBool.Add(FCString::ToBool(*ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayUint8(TArray<FString> ArrayString, TArray<uint8> &ArrayByte)
{
    for (FString ArrayElement : ArrayString)
    {
        ArrayByte.Add(FCString::Atoi((*ArrayElement)));
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayInt32(TArray<FString> ArrayString, TArray<int32> &ArrayInt32)
{
    for (FString ArrayElement : ArrayString)
    {
        ArrayInt32.Add(FCString::Atoi(*ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayInt64(TArray<FString> ArrayString, TArray<int64> &ArrayInt64)
{
    for (FString ArrayElement : ArrayString)
    {
        ArrayInt64.Add(FCString::Atoi64(*ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayFloat(TArray<FString> ArrayString, TArray<float> &ArrayFloat)
{
    for (FString ArrayElement : ArrayString)
    {
        ArrayFloat.Add(FCString::Atof(*ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayName(TArray<FString> ArrayString, TArray<FName> &ArrayName)
{
    for (FString ArrayElement : ArrayString)
    {
        ArrayName.Add(FName(*ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayText(TArray<FString> ArrayString, TArray<FText> &ArrayText)
{
    for (FString ArrayElement : ArrayString)
    {
        ArrayText.Add(FText::AsCultureInvariant(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayVector(TArray<FString> ArrayString, TArray<FVector> &ArrayVector)
{
    FVector OutConvertedVector;
    for (FString ArrayElement : ArrayString)
    {
        OutConvertedVector.InitFromString(ArrayElement);
        ArrayVector.Add(OutConvertedVector);
    }
}

void UBVar_to_varBPLibrary::ArrayStringToArrayRotator(TArray<FString> ArrayString, TArray<FRotator> &ArrayRotator)
{
    FRotator OutConvertedRotator;
    for (FString ArrayElement : ArrayString)
    {
        OutConvertedRotator.InitFromString(ArrayElement);
        ArrayRotator.Add(OutConvertedRotator);
    }
}
// Text

void UBVar_to_varBPLibrary::ArrayTextToArrayBool(TArray<FText> ArrayText, TArray<bool> &ArrayBool)
{
    for (FText ArrayElement : ArrayText)
    {
        ArrayBool.Add(FCString::ToBool(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayUint8(TArray<FText> ArrayText, TArray<uint8> &ArrayByte)
{
    for (FText ArrayElement : ArrayText)
    {
        ArrayByte.Add(FCString::Atoi((*ArrayElement.ToString())));
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayInt32(TArray<FText> ArrayText, TArray<int32> &ArrayInt32)
{
    for (FText ArrayElement : ArrayText)
    {
        ArrayInt32.Add(FCString::Atoi(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayInt64(TArray<FText> ArrayText, TArray<int64> &ArrayInt64)
{
    for (FText ArrayElement : ArrayText)
    {
        ArrayInt64.Add(FCString::Atoi64(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayFloat(TArray<FText> ArrayText, TArray<float> &ArrayFloat)
{
    for (FText ArrayElement : ArrayText)
    {
        ArrayFloat.Add(FCString::Atof(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayString(TArray<FText> ArrayText, TArray<FString> &ArrayString)
{
    for (FText ArrayElement : ArrayText)
    {
        ArrayString.Add(*ArrayElement.ToString());
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayName(TArray<FText> ArrayText, TArray<FName> &ArrayName)
{
    for (FText ArrayElement : ArrayText)
    {
        ArrayName.Add(FName(*ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayVector(TArray<FText> ArrayText, TArray<FVector> &ArrayVector)
{
    FVector OutConvertedVector;
    for (FText ArrayElement : ArrayText)
    {
        OutConvertedVector.InitFromString(ArrayElement.ToString());
        ArrayVector.Add(OutConvertedVector);
    }
}

void UBVar_to_varBPLibrary::ArrayTextToArrayRotator(TArray<FText> ArrayText, TArray<FRotator> &ArrayRotator)
{
    FRotator OutConvertedRotator;
    for (FText ArrayElement : ArrayText)
    {
        OutConvertedRotator.InitFromString(ArrayElement.ToString());
        ArrayRotator.Add(OutConvertedRotator);
    }
}

// Vector

void UBVar_to_varBPLibrary::ArrayVectorToArrayName(TArray<FVector> ArrayVector, TArray<FName> &ArrayName)
{
    for (const auto &ArrayElement : ArrayVector)
    {

        ArrayName.Add(*ArrayElement.ToString());
    }

}

void UBVar_to_varBPLibrary::ArrayVectorToArrayString(TArray<FVector> ArrayVector, TArray<FString> &ArrayString)
{
    for (const auto &ArrayElement : ArrayVector)
    {
        ArrayString.Add(*ArrayElement.ToString());
    }
}

void UBVar_to_varBPLibrary::ArrayVectorToArrayText(TArray<FVector> ArrayVector, TArray<FText> &ArrayText)
{
    for (const auto &ArrayElement : ArrayVector)
    {
        ArrayText.Add(FText::AsCultureInvariant(ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayVectorToArrayRotator(TArray<FVector> ArrayVector, TArray<FRotator> &ArrayRotator)
{
    for (const auto &ArrayElement : ArrayVector)
    {
        ArrayRotator.Add(ArrayElement.ToOrientationRotator());
    }
}

void UBVar_to_varBPLibrary::ArrayVectorToArrayTransformLocation(TArray<FVector> ArrayVector, TArray<FTransform> &ArrayTransform)
{
    for (const auto &ArrayElement : ArrayVector)
    {
        ArrayTransform.Add(FTransform(ArrayElement));
    }
}

void UBVar_to_varBPLibrary::ArrayVectorToArrayTransformScale(TArray<FVector> ArrayVector, TArray<FTransform> &ArrayTransform)
{
    for (const auto &ArrayElement : ArrayVector)
    {
        FTransform IntermediateArrayTransform{
            FRotator{},           // Rotation
            FVector{},            // Location
            FVector{ArrayElement} // Scale
        };
        ArrayTransform.Add(IntermediateArrayTransform);
    }
}

// Rotator

void UBVar_to_varBPLibrary::ArrayRotatorToArrayName(TArray<FRotator> ArrayRotator, TArray<FName> &ArrayName)
{
    for (const auto &ArrayElement : ArrayRotator)
    {
        ArrayName.Add(*ArrayElement.ToString());
    }
}

void UBVar_to_varBPLibrary::ArrayRotatorToArrayString(TArray<FRotator> ArrayRotator, TArray<FString> &ArrayString)
{
    for (const auto &ArrayElement : ArrayRotator)
    {
        ArrayString.Add(*ArrayElement.ToString());
    }
}

void UBVar_to_varBPLibrary::ArrayRotatorToArrayText(TArray<FRotator> ArrayRotator, TArray<FText> &ArrayText)
{
    for (const auto &ArrayElement : ArrayRotator)
    {
        ArrayText.Add(FText::AsCultureInvariant(ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayRotatorToArrayVector(TArray<FRotator> ArrayRotator, TArray<FVector> &ArrayVector)
{
    for (const auto &ArrayElement : ArrayRotator)
    {
        ArrayVector.Add(ArrayElement.Vector());
    }
}

void UBVar_to_varBPLibrary::ArrayRotatorToArrayTransform(TArray<FRotator> ArrayRotator, TArray<FTransform> &ArrayTransform)
{
    for (const auto &ArrayElement : ArrayRotator)
    {
        ArrayTransform.Add(FTransform(ArrayElement));
    }
}

// Transform

void UBVar_to_varBPLibrary::ArrayTransformToArrayName(TArray<FTransform> ArrayTransform, TArray<FName> &ArrayName)
{
    for (const auto &ArrayElement : ArrayTransform)
    {
        ArrayName.Add(*ArrayElement.ToString());
    }
}

void UBVar_to_varBPLibrary::ArrayTransformToArrayString(TArray<FTransform> ArrayTransform, TArray<FString> &ArrayString)
{
    for (const auto &ArrayElement : ArrayTransform)
    {
        ArrayString.Add(*ArrayElement.ToString());
    }
}

void UBVar_to_varBPLibrary::ArrayTransformToArrayText(TArray<FTransform> ArrayTransform, TArray<FText> &ArrayText)
{
    for (const auto &ArrayElement : ArrayTransform)
    {
        ArrayText.Add(FText::AsCultureInvariant(ArrayElement.ToString()));
    }
}

void UBVar_to_varBPLibrary::ArrayTransformToArrayVectorLocation(TArray<FTransform> ArrayTransform, TArray<FVector> &ArrayVector)
{
    for (const auto &ArrayElement : ArrayTransform)
    {
        ArrayVector.Add(ArrayElement.GetLocation());
    }
}

void UBVar_to_varBPLibrary::ArrayTransformToArrayRotator(TArray<FTransform> ArrayTransform, TArray<FRotator> &ArrayRotator)
{
    for (const auto &ArrayElement : ArrayTransform)
    {
        ArrayRotator.Add(ArrayElement.Rotator());
    }
}

void UBVar_to_varBPLibrary::ArrayTransformToArrayVectorScale(TArray<FTransform> ArrayTransform, TArray<FVector> &ArrayVector)
{
    for (const auto &ArrayElement : ArrayTransform)
    {
        ArrayVector.Add(ArrayElement.GetScale3D());
    }
}