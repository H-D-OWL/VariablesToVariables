// Copyright H.D OWL. All rights reserved.
#pragma once
#include "GenericPlatform/GenericPlatformApplicationMisc.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Variables_to_variablesBPLibrary.generated.h"

UCLASS()
class UBVar_to_varBPLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

  protected:
      
    // Varriable To Varriable

       // Bool

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Bool", DisplayName = " Bool To Int64", meta = (CompactNodeTitle = "->", ToolTip = " Bool To Int64", Keywords = "To"))
    static void BoolToInt64(bool Bool, int64 &Int64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Bool", DisplayName = " Bool To Name", meta = (CompactNodeTitle = "->", ToolTip = " Bool To Name", Keywords = "To"))
    static void BoolToName(bool Bool, FName &Name);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Bool", DisplayName = " Bool To Vector", meta = (CompactNodeTitle = "->", ToolTip = "Bool To Vector", Keywords = "To"))
    static void BoolToVector(bool Bool, FVector &Vector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Bool", DisplayName = " Bool To Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Bool To Rotator", Keywords = "To"))
    static void BoolToRotator(bool Bool, FRotator &Rotator);

       // Uint8 (Byte)

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Byte", DisplayName = " Byte To Bool", meta = (CompactNodeTitle = "->", ToolTip = " Byte To Bool", Keywords = "To"))
    static void Uint8ToBool(uint8 Byte, bool &Bool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Byte", DisplayName = " Byte To Name", meta = (CompactNodeTitle = "->", ToolTip = " Byte To Name", Keywords = "To"))
    static void Uint8ToName(uint8 Byte, FName &Name);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Byte", DisplayName = " Byte To Vector", meta = (CompactNodeTitle = "->", ToolTip = "Byte To Vector", Keywords = "To"))
    static void Uint8ToVector(uint8 Byte, FVector &Vector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Byte", DisplayName = " Byte To Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Byte To Rotator", Keywords = "To"))
    static void Uint8ToRotator(uint8 Byte, FRotator &Rotator);
       // Int32

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Int32", DisplayName = " Int32 To Name", meta = (CompactNodeTitle = "->", ToolTip = " Int32 To Name", Keywords = "To"))
    static void Int32ToName(int32 Int32, FName &Name);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Int32", DisplayName = " Int32 To Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Int32 To Rotator", Keywords = "To"))
    static void Int32ToRotator(int32 Int32, FRotator &Rotator);

       // Int64

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Int64", DisplayName = " Int64 To Bool", meta = (CompactNodeTitle = "->", ToolTip = " Int64 To Bool", Keywords = "To"))
    static void Int64ToBool(int64 Int64, bool &Bool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Int64", DisplayName = " Int64 To Name", meta = (CompactNodeTitle = "->", ToolTip = " Int64 To Name", Keywords = "To"))
    static void Int64ToName(int64 Int64, FName &Name);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Int64", DisplayName = " Int64 To Vector", meta = (CompactNodeTitle = "->", ToolTip = "Int64 To Vector", Keywords = "To"))
    static void Int64ToVector(int64 Int64, FVector &Vector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Int64", DisplayName = " Int64 To Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Int64 To Rotator", Keywords = "To"))
    static void Int64ToRotator(int64 Int64, FRotator &Rotator);

           // Float

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Float", DisplayName = " Float To Bool", meta = (CompactNodeTitle = "->", ToolTip = " Float To Bool", Keywords = "To"))
    static void FloatToBool(float Float, bool &Bool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Float", DisplayName = " Float To Byte", meta = (CompactNodeTitle = "->", ToolTip = "Float To Byte", Keywords = "To"))
    static void FloatToUint8(float Float, uint8 &Byte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Float", DisplayName = " Float To Name", meta = (CompactNodeTitle = "->", ToolTip = " Float To Name", Keywords = "To"))
    static void FloatToName(float Float, FName &Name);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Float", DisplayName = " Float To Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Float To Rotator", Keywords = "To"))
    static void FloatToRotator(float Float, FRotator &Rotator);

          // Name

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Name", DisplayName = " Name To Bool", meta = (CompactNodeTitle = "->", ToolTip = " Name To Bool", Keywords = "To"))
    static void NameToBool(FName Name, bool &Bool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Name", DisplayName = " Name To Byte", meta = (CompactNodeTitle = "->", ToolTip = "Name To Byte", Keywords = "To"))
    static void NameToUint8(FName Name, uint8 &Byte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Name", DisplayName = " Name To Int32", meta = (CompactNodeTitle = "->", ToolTip = "Name To Int32", Keywords = "To"))
    static void NameToInt32(FName Name, int32 &Int32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Name", DisplayName = " Name To Int64", meta = (CompactNodeTitle = "->", ToolTip = "Name To Int64", Keywords = "To"))
    static void NameToInt64(FName Name, int64 &Int64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Name", DisplayName = " Name To Float", meta = (CompactNodeTitle = "->", ToolTip = "Name To Float", Keywords = "To"))
    static void NameToFloat(FName Name, float &Float);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Name", DisplayName = " Name To Vector", meta = (CompactNodeTitle = "->", ToolTip = " Name To Vector", Keywords = "To"))
    static void NameToVector(FName Name, FVector &Vector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Name", DisplayName = " Name To Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Name To Rotator", Keywords = "To"))
    static void NameToRotator(FName Name, FRotator &Rotator);

       // String

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | String", DisplayName = " String To Bool", meta = (CompactNodeTitle = "->", ToolTip = " String To Bool", Keywords = "To"))
    static void StringToBool(FString String, bool &Bool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | String", DisplayName = " String To Byte", meta = (CompactNodeTitle = "->", ToolTip = "String To Byte", Keywords = "To"))
    static void StringToUint8(FString String, uint8 &Byte);

       // Text

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Bool", meta = (CompactNodeTitle = "->", ToolTip = " Text To Bool", Keywords = "To"))
    static void TextToBool(const FText &Text, bool &Bool); 

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Byte", meta = (CompactNodeTitle = "->", ToolTip = "Text To Byte", Keywords = "To"))
    static void TextToUint8(const FText &Text, uint8 &Byte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Int32", meta = (CompactNodeTitle = "->", ToolTip = "Text To Int32", Keywords = "To"))
    static void TextToInt32(const FText &Text, int32 &Int32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Int64", meta = (CompactNodeTitle = "->", ToolTip = "Text To Int64", Keywords = "To"))
    static void TextToInt64(const FText &Text, int64 &Int64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Float", meta = (CompactNodeTitle = "->", ToolTip = "Text To Float", Keywords = "To"))
    static void TextToFloat(const FText &Text, float &Float);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Name", meta = (CompactNodeTitle = "->", ToolTip = "Text To Name", Keywords = "To"))
    static void TextToName(const FText &Text, FName &Name);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Vector", meta = (CompactNodeTitle = "->", ToolTip = " Text To Vector", Keywords = "To"))
    static void TextToVector(const FText &Text, FVector &Vector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Text", DisplayName = " Text To Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Text To Rotator", Keywords = "To"))
    static void TextToRotator(const FText &Text, FRotator &Rotator);

       // Vector

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Vector", DisplayName = " Vector To Name", meta = (CompactNodeTitle = "->", ToolTip = " Vector To Name", Keywords = "To"))
    static void VectorToName(FVector Vector, FName &Name); 

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Vector", DisplayName = " Vector To Transform (Scale)", meta = (CompactNodeTitle = "Sca", ToolTip = " Converts a vector to a transform. Uses vector as scale", Keywords = "To"))
    static void VectorToTransformScale(FVector Vector, FTransform &Transform);

       // Rotator

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Rotator", DisplayName = " Rotator To Name", meta = (CompactNodeTitle = "->", ToolTip = " Rotator To Name", Keywords = "To"))
    static void RotatorToName(FRotator Rotator, FName &Name); 

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Rotator", DisplayName = " Rotator To Transform", meta = (CompactNodeTitle = "->", ToolTip = "Rotator To Transform", Keywords = "To"))
    static void RotatorToTransform(FRotator Rotator, FTransform &Transform);


       // Transform

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Transform", DisplayName = " Transform To Name", meta = (CompactNodeTitle = "->", ToolTip = " Transform To Name", Keywords = "To"))
    static void TransformToName(FTransform Transform, FName &Name); 

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Transform", DisplayName = " Transform To Vector (Location)", meta = (CompactNodeTitle = "Loc", ToolTip = "Transform To Vector (Location)", Keywords = "To"))
    static void TransformToVectorLocation(FTransform Transform, FVector &Vector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Transform", DisplayName = " Transform To Rotator", meta = (CompactNodeTitle = "->", ToolTip = " Transform To Rotator", Keywords = "To"))
    static void TransformToRotator(FTransform Transform, FRotator &Rotator); 

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Varriable To Varriable | Transform", DisplayName = " Transform To Vector (Scale)", meta = (CompactNodeTitle = "Sca", ToolTip = "Transform To Vector (Scale)", Keywords = "To"))
    static void TransformToVectorScale(FTransform Transform, FVector &Vector);


    // Array To Array

       // Bool

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Byte", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Byte", Keywords = "To"))
    static void ArrayBoolToArrayUint8(TArray<bool> ArrayBool, TArray<uint8> &ArrayUint8);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Int32", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Int32", Keywords = "To"))
    static void ArrayBoolToArrayInt32(TArray<bool> ArrayBool, TArray<int32> &ArrayInt32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Int64", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Int64", Keywords = "To"))
    static void ArrayBoolToArrayInt64(TArray<bool> ArrayBool, TArray<int64> &ArrayInt64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Float", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Float", Keywords = "To"))
    static void ArrayBoolToArrayfloat(TArray<bool> ArrayBool, TArray<float> &ArrayFloat);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Name", Keywords = "To"))
    static void ArrayBoolToArrayName(TArray<bool> ArrayBool, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array String", Keywords = "To"))
    static void ArrayBoolToArrayString(TArray<bool> ArrayBool, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Text", Keywords = "To"))
    static void ArrayBoolToArrayText(TArray<bool> ArrayBool, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Vector", Keywords = "To"))
    static void ArrayBoolToArrayVector(TArray<bool> ArrayBool, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Bool", DisplayName = "Array Bool To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array Bool To Array Rotator", Keywords = "To"))
    static void ArrayBoolToArrayRotator(TArray<bool> ArrayBool, TArray<FRotator> &ArrayRotator);

       //Uint8 (Byte)

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Bool", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Bool", Keywords = "To"))
    static void ArrayUint8ToArrayBool(TArray<uint8> ArrayByte, TArray<bool> &ArrayBool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Int32", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Int32", Keywords = "To"))
    static void ArrayUint8ToArrayInt32(TArray<uint8> ArrayByte, TArray<int32> &ArrayInt32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Int64", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Int64", Keywords = "To"))
    static void ArrayUint8ToArrayInt64(TArray<uint8> ArrayByte, TArray<int64> &ArrayInt64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Float", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Float", Keywords = "To"))
    static void ArrayUint8ToArrayfloat(TArray<uint8> ArrayByte, TArray<float> &ArrayFloat);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Name", Keywords = "To"))
    static void ArrayUint8ToArrayName(TArray<uint8> ArrayByte, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array String", Keywords = "To"))
    static void ArrayUint8ToArrayString(TArray<uint8> ArrayByte, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Text", Keywords = "To"))
    static void ArrayUint8ToArrayText(TArray<uint8> ArrayByte, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Vector", Keywords = "To"))
    static void ArrayUint8ToArrayVector(TArray<uint8> ArrayByte, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Byte", DisplayName = "Array Byte To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array Byte To Array Rotator", Keywords = "To"))
    static void ArrayUint8ToArrayRotator(TArray<uint8> ArrayByte, TArray<FRotator> &ArrayRotator);

       //Int32

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Bool", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Bool", Keywords = "To"))
    static void ArrayInt32ToArrayBool(TArray<int32> ArrayInt32, TArray<bool> &ArrayBool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Byte", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Byte", Keywords = "To"))
    static void ArrayInt32ToArrayUint8(TArray<int32> ArrayInt32, TArray<uint8> &ArrayByte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Int64", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Int64", Keywords = "To"))
    static void ArrayInt32ToArrayInt64(TArray<int32> ArrayInt32, TArray<int64> &ArrayInt64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Float", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Float", Keywords = "To"))
    static void ArrayInt32ToArrayfloat(TArray<int32> ArrayInt32, TArray<float> &ArrayFloat);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Name", Keywords = "To"))
    static void ArrayInt32ToArrayName(TArray<int32> ArrayInt32, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array String", Keywords = "To"))
    static void ArrayInt32ToArrayString(TArray<int32> ArrayInt32, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Text", Keywords = "To"))
    static void ArrayInt32ToArrayText(TArray<int32> ArrayInt32, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Vector", Keywords = "To"))
    static void ArrayInt32ToArrayVector(TArray<int32> ArrayInt32, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int32", DisplayName = "Array Int32 To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array Int32 To Array Rotator", Keywords = "To"))
    static void ArrayInt32ToArrayRotator(TArray<int32> ArrayInt32, TArray<FRotator> &ArrayRotator);

       //Int64

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Bool", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Bool", Keywords = "To"))
    static void ArrayInt64ToArrayBool(TArray<int64> ArrayInt64, TArray<bool> &ArrayBool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Byte", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Byte", Keywords = "To"))
    static void ArrayInt64ToArrayUint8(TArray<int64> ArrayInt64, TArray<uint8> &ArrayByte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Int32", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Int32", Keywords = "To"))
    static void ArrayInt64ToArrayInt32(TArray<int64> ArrayInt64, TArray<int32> &ArrayInt32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Float", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Float", Keywords = "To"))
    static void ArrayInt64ToArrayfloat(TArray<int64> ArrayInt64, TArray<float> &ArrayFloat);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Name", Keywords = "To"))
    static void ArrayInt64ToArrayName(TArray<int64> ArrayInt64, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array String", Keywords = "To"))
    static void ArrayInt64ToArrayString(TArray<int64> ArrayInt64, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Text", Keywords = "To"))
    static void ArrayInt64ToArrayText(TArray<int64> ArrayInt64, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Vector", Keywords = "To"))
    static void ArrayInt64ToArrayVector(TArray<int64> ArrayInt64, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Int64", DisplayName = "Array Int64 To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array Int64 To Array Rotator", Keywords = "To"))
    static void ArrayInt64ToArrayRotator(TArray<int64> ArrayInt64, TArray<FRotator> &ArrayRotator);

       //Float

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Bool", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Bool", Keywords = "To"))
    static void ArrayFloatToArrayBool(TArray<float> ArrayFloat, TArray<bool> &ArrayBool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Byte", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Byte", Keywords = "To"))
    static void ArrayFloatToArrayUint8(TArray<float> ArrayFloat, TArray<uint8> &ArrayByte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Int32", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Int32", Keywords = "To"))
    static void ArrayFloatToArrayInt32(TArray<float> ArrayFloat, TArray<int32> &ArrayInt32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Int64", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Int64", Keywords = "To"))
    static void ArrayFloatToArrayInt64(TArray<float> ArrayFloat, TArray<int64> &ArrayInt64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Name", Keywords = "To"))
    static void ArrayFloatToArrayName(TArray<float> ArrayFloat, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array String", Keywords = "To"))
    static void ArrayFloatToArrayString(TArray<float> ArrayFloat, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Text", Keywords = "To"))
    static void ArrayFloatToArrayText(TArray<float> ArrayFloat, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Vector", Keywords = "To"))
    static void ArrayFloatToArrayVector(TArray<float> ArrayFloat, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Float", DisplayName = "Array Float To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array Float To Array Rotator", Keywords = "To"))
    static void ArrayFloatToArrayRotator(TArray<float> ArrayFloat, TArray<FRotator> &ArrayRotator);

       // Name

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Bool", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Bool", Keywords = "To"))
    static void ArrayNameToArrayBool(TArray<FName> ArrayName, TArray<bool> &ArrayBool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Byte", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Byte", Keywords = "To"))
    static void ArrayNameToArrayUint8(TArray<FName> ArrayName, TArray<uint8> &ArrayByte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Int32", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Int32", Keywords = "To"))
    static void ArrayNameToArrayInt32(TArray<FName> ArrayName, TArray<int32> &ArrayInt32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Int64", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Int64", Keywords = "To"))
    static void ArrayNameToArrayInt64(TArray<FName> ArrayName, TArray<int64> &ArrayInt64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Float", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Float", Keywords = "To"))
    static void ArrayNameToArrayFloat(TArray<FName> ArrayName, TArray<float> &ArrayFloat);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array String", Keywords = "To"))
    static void ArrayNameToArrayName(TArray<FName> ArrayName, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Text", Keywords = "To"))
    static void ArrayNameToArrayText(TArray<FName> ArrayName, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Vector", Keywords = "To"))
    static void ArrayNameToArrayVector(TArray<FName> ArrayName, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Name", DisplayName = "Array Name To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array Name To Array Rotator", Keywords = "To"))
    static void ArrayNameToArrayRotator(TArray<FName> ArrayName, TArray<FRotator> &ArrayRotator);

       // String

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Bool", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Bool", Keywords = "To"))
    static void ArrayStringToArrayBool(TArray<FString> ArrayString, TArray<bool> &ArrayBool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Byte", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Byte", Keywords = "To"))
    static void ArrayStringToArrayUint8(TArray<FString> ArrayString, TArray<uint8> &ArrayByte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Int32", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Int32", Keywords = "To"))
    static void ArrayStringToArrayInt32(TArray<FString> ArrayString, TArray<int32> &ArrayInt32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Int64", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Int64", Keywords = "To"))
    static void ArrayStringToArrayInt64(TArray<FString> ArrayString, TArray<int64> &ArrayInt64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Float", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Float", Keywords = "To"))
    static void ArrayStringToArrayFloat(TArray<FString> ArrayString, TArray<float> &ArrayFloat);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Name", Keywords = "To"))
    static void ArrayStringToArrayName(TArray<FString> ArrayString, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Text", Keywords = "To"))
    static void ArrayStringToArrayText(TArray<FString> ArrayString, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Vector", Keywords = "To"))
    static void ArrayStringToArrayVector(TArray<FString> ArrayString, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array String To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array String To Array Rotator", Keywords = "To"))
    static void ArrayStringToArrayRotator(TArray<FString> ArrayString, TArray<FRotator> &ArrayRotator);

        // Text

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Bool", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Bool", Keywords = "To"))
    static void ArrayTextToArrayBool(TArray<FText> ArrayText, TArray<bool> &ArrayBool);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Byte", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Byte", Keywords = "To"))
    static void ArrayTextToArrayUint8(TArray<FText> ArrayText, TArray<uint8> &ArrayByte);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Int32", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Int32", Keywords = "To"))
    static void ArrayTextToArrayInt32(TArray<FText> ArrayText, TArray<int32> &ArrayInt32);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Int64", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Int64", Keywords = "To"))
    static void ArrayTextToArrayInt64(TArray<FText> ArrayText, TArray<int64> &ArrayInt64);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Float", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Float", Keywords = "To"))
    static void ArrayTextToArrayFloat(TArray<FText> ArrayText, TArray<float> &ArrayFloat);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array String", Keywords = "To"))
    static void ArrayTextToArrayString(TArray<FText> ArrayText, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Name", Keywords = "To"))
    static void ArrayTextToArrayName(TArray<FText> ArrayText, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Vector", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Vector", Keywords = "To"))
    static void ArrayTextToArrayVector(TArray<FText> ArrayText, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_String", DisplayName = "Array Text To Array Rotator", meta = (CompactNodeTitle = "->", ToolTip = "Array Text To Array Rotator", Keywords = "To"))
    static void ArrayTextToArrayRotator(TArray<FText> ArrayText, TArray<FRotator> &ArrayRotator);

        // Vector

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Vector", DisplayName = "Array Vector To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Vector To Array Name", Keywords = "To"))
    static void ArrayVectorToArrayName(TArray<FVector> ArrayVector, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Vector", DisplayName = "Array Vector To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Vector To Array String", Keywords = "To"))
    static void ArrayVectorToArrayString(TArray<FVector> ArrayVector, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Vector", DisplayName = "Array Vector To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Vector To Array Text", Keywords = "To"))
    static void ArrayVectorToArrayText(TArray<FVector> ArrayVector, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Vector", DisplayName = "Array Rotation From X Array Vector", meta = (ToolTip = "Return the array FRotator orientation corresponding to the direction in which yhe vector points. Sets Yaw and Pitch to the numbers, and sets Roll to zero because the roll can not be determined from a vector", Keywords = "To"))
    static void ArrayVectorToArrayRotator(TArray<FVector> ArrayVector, TArray<FRotator> &ArrayRotator);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Vector", DisplayName = "Array Vector To Array Transform (Location)", meta = (CompactNodeTitle = "Loc", ToolTip = "Array Vector To Array Transform. Used vector as location", Keywords = "To"))
    static void ArrayVectorToArrayTransformLocation(TArray<FVector> ArrayVector, TArray<FTransform> &ArrayTransform);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Vector", DisplayName = "Array Vector To Array Transform (Scale)", meta = (CompactNodeTitle = "Sca", ToolTip = "Array Vector To Array Transform. Used vector as scale", Keywords = "To"))
    static void ArrayVectorToArrayTransformScale(TArray<FVector> ArrayVector, TArray<FTransform> &ArrayTransform);

        // Rotator

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Rotator", DisplayName = "Array Rotator To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Rotator To Array Name", Keywords = "To"))
    static void ArrayRotatorToArrayName(TArray<FRotator> ArrayRotator, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Rotator", DisplayName = "Array Rotator To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Rotator To Array String", Keywords = "To"))
    static void ArrayRotatorToArrayString(TArray<FRotator> ArrayRotator, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Rotator", DisplayName = "Array Rotator To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Rotator To Array Text", Keywords = "To"))
    static void ArrayRotatorToArrayText(TArray<FRotator> ArrayRotator, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Rotator", DisplayName = "Get Array Rotation X Array Vector", meta = (ToolTip = "Get an array of X direction vectors after this rotation", Keywords = "To"))
    static void ArrayRotatorToArrayVector(TArray<FRotator> ArrayRotator, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Rotator", DisplayName = "Array Rotator To Array Transform", meta = (CompactNodeTitle = "->", ToolTip = "Array Rotator To Array Transform", Keywords = "To"))
    static void ArrayRotatorToArrayTransform(TArray<FRotator> ArrayRotator, TArray<FTransform> &ArrayTransform);

        // Transform

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Transform", DisplayName = "Array Transform To Array Name", meta = (CompactNodeTitle = "->", ToolTip = "Array Transform To Array Name", Keywords = "To"))
    static void ArrayTransformToArrayName(TArray<FTransform> ArrayTransform, TArray<FName> &ArrayName);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Transform", DisplayName = "Array Transform To Array String", meta = (CompactNodeTitle = "->", ToolTip = "Array Transform To Array String", Keywords = "To"))
    static void ArrayTransformToArrayString(TArray<FTransform> ArrayTransform, TArray<FString> &ArrayString);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Transform", DisplayName = "Array Transform To Array Text", meta = (CompactNodeTitle = "->", ToolTip = "Array Transform To Array Text", Keywords = "To"))
    static void ArrayTransformToArrayText(TArray<FTransform> ArrayTransform, TArray<FText> &ArrayText);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Transform", DisplayName = "Array Transform To Array Vector (Location)", meta = (CompactNodeTitle = "Loc",ToolTip = "Array Transform To Array Vector (Location)", Keywords = "To"))
    static void ArrayTransformToArrayVectorLocation(TArray<FTransform> ArrayTransform, TArray<FVector> &ArrayVector);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Transform", DisplayName = "Array Transform To Array Rotator", meta = (CompactNodeTitle = "Rot",ToolTip = "Array Transform To Array Rotator", Keywords = "To"))
    static void ArrayTransformToArrayRotator(TArray<FTransform> ArrayTransform, TArray<FRotator> &ArrayRotator);

    UFUNCTION(BlueprintPure, Category = "Variables to variables | Array_To_Array | Array_Transform", DisplayName = "Array Transform To Array Vector (Scale)", meta = (CompactNodeTitle = "Sca",ToolTip = "Array Transform To Array Vector (Scale)", Keywords = "To"))
    static void ArrayTransformToArrayVectorScale(TArray<FTransform> ArrayTransform, TArray<FVector> &ArrayVector);
};
